class Dataloader:
    def __init__(self, root_dir, num_classes, ext):
        self.train_dir = root_dir / "train"
        self.test_dir = root_dir / "test"
        self.num_classes = num_classes
        self.ext = ext  # 图片文件扩展名".jpg"

    def load_paths_and_labels(self):
        train_paths, train_labels = [], []
        test_paths, test_labels = [], []
        # 训练集
        for img_path in sorted(self.train_dir.glob(f"*{self.ext}")):
            try:
                idx = int(img_path.stem)  # 检查文件名是不是整数，不含后缀
            except ValueError:
                continue
            category = idx // 100  # 每100张图片属于一个类别
            if 0 <= category < self.num_classes:
                train_paths.append(img_path)
                train_labels.append(category)

        # 测试集
        for img_path in sorted(self.test_dir.glob(f"*{self.ext}")):
            try:
                idx = int(img_path.stem)
            except ValueError:
                continue
            category = idx // 100
            if 0 <= category < self.num_classes:
                test_paths.append(img_path)
                test_labels.append(category)
        # 打印读取结果
        # print("训练集:", train_paths)
        # print("测试集:", test_labels)
        print(f"[Dataloader] 训练集路径数量: {len(train_paths)}, 标签数量: {len(train_labels)}")
        print(f"[Dataloader] 测试集路径数量: {len(test_paths)}, 标签数量: {len(test_labels)}")
        return train_paths, train_labels, test_paths, test_labels
