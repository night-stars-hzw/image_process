from pathlib import Path
from typing import List
import numpy as np
from PIL import Image
from skimage.feature import local_binary_pattern, SIFT
from skimage.feature import graycomatrix, graycoprops
import torch
import torch.nn as nn
import torchvision.transforms as T
from torchvision import models
from sklearn.cluster import KMeans
import matplotlib.colors as mcolors
from tqdm import tqdm
class FeatureExtractor:
    def __init__(self, vocab_size, glcm_distances, glcm_angles, glcm_levels, lbp_p, lbp_r, lbp_method, lbp_hist_size,
                 color_hist_bins, use_cnn, device):
        # GLCM 参数
        self.glcm_distances = glcm_distances  # GLCM中灰度共生矩阵的距离列表
        self.glcm_angles = glcm_angles  # GLCM中灰度共生矩阵的角度列表
        self.glcm_levels = glcm_levels  # 灰度量化级别
        # LBP 参数
        self.lbp_p = lbp_p  # 邻域点数
        self.lbp_r = lbp_r  # 半径
        self.lbp_method = lbp_method  # LBP方法，"uniform"
        self.lbp_hist_size = lbp_hist_size  # LBP直方图长度
        # 颜色直方图参数
        self.color_hist_bins = color_hist_bins  # HSV三通道直方图的bin数量，例如 (16,16,16)
        # SIFT + 视觉词典参数
        self.sift = SIFT()
        self.vocab_size = vocab_size  # 视觉词典大小
        self.kmeans_model = None
        self.device = device
        # 是否使用 CNN（ResNet50）特征
        self.use_cnn = use_cnn
        if self.use_cnn:
            self._build_cnn_model()
        # ResNet50 输入预处理：Resize -> ToTensor -> Normalize
        self.cnn_transform = T.Compose([
            T.Resize((224, 224)),  # ResNet50 要求输入尺寸为 224x224
            T.ToTensor(),
            T.Normalize(mean=[0.485, 0.456, 0.406],
                        std=[0.229, 0.224, 0.225])
        ])

        # 各特征维度
        self.dim_glcm = 4 * len(self.glcm_distances) * len(self.glcm_angles)  # GLCM 属性维度
        self.dim_bow = self.vocab_size  # BOW 维度
        self.dim_lbp = self.lbp_hist_size  # LBP 维度
        self.dim_color = sum(self.color_hist_bins)  # 颜色直方图维度
        self.dim_cnn = 2048  # ResNet50 去掉 FC 层后输出特征维度

    def _build_cnn_model(self):
        # 载入预训练权重
        model = models.resnet50(weights=models.ResNet50_Weights.IMAGENET1K_V1)
        # 去掉最后的全连接层, 用于特征提取
        modules = list(model.children())[:-1]
        self.cnn_model = nn.Sequential(*modules).to(self.device)
        self.cnn_model.eval()  # 设置为评估模式，关闭 dropout、batchnorm 更新等

    @staticmethod
    def _pil_to_gray_array(pil_img, levels=256):
        gray = pil_img.convert("L")  # 转为灰度图
        arr = np.array(gray, dtype=np.uint8)
        return arr.copy()

    @staticmethod
    def _pil_to_rgb_array(pil_img):
        rgb = pil_img.convert("RGB")
        return np.array(rgb, dtype=np.uint8)

    def build_sift_vocab(self, train_paths: List[Path]):
        all_descriptors = []
        for path in tqdm(train_paths, desc="Building SIFT vocab"):
            pil_img = Image.open(path)
            # 转为量化灰度图，取值范围 [0, glcm_levels-1]
            gray_arr = self._pil_to_gray_array(pil_img, levels=self.glcm_levels)
            # 归一化到 [0,1]
            gray_float = gray_arr.astype(np.float32) / 255.0
            try:
                # 提取 SIFT keypoints 和 descriptors
                self.sift.detect_and_extract(gray_float)
            except RuntimeError:
                # 跳过无法提取SIFT特征的图像
                continue

            des = self.sift.descriptors  # descriptors: shape=(n_keypoints, 128)
            if des is not None and des.size > 0:
                all_descriptors.append(des)

        if not all_descriptors:
            raise ValueError("SIFT描述子为空，无法构建视觉词典。")

        # 将所有图片的 descriptors 堆叠，得到形状 (总关键点数, 128)
        all_descriptors = np.vstack(all_descriptors)
        # print(f"[build_sift_vocab] 总 descriptors 数量: {all_descriptors.shape}")  # (n_descriptors, 128)

        # 使用 KMeans 聚类，词典大小为 vocab_size
        self.kmeans_model = KMeans(n_clusters=self.vocab_size, n_init=10, random_state=42)
        self.kmeans_model.fit(all_descriptors)
        # print(f"[build_sift_vocab] 已训练 KMeans 词典，聚类中心形状: {self.kmeans_model.cluster_centers_.shape}")  # (vocab_size, 128)

    def extract_glcm(self, pil_img):
        gray = self._pil_to_gray_array(pil_img, levels=self.glcm_levels)  # shape=(H, W)
        # 计算灰度共生矩阵，返回形状 (levels, levels, len(distances), len(angles))
        glcm = graycomatrix(gray, distances=self.glcm_distances, angles=self.glcm_angles, levels=self.glcm_levels,
                            symmetric=True, normed=True)
        # 需要计算的四种属性
        props = ["contrast", "correlation", "energy", "homogeneity"]
        feats = []
        for prop in props:
            tmp = graycoprops(glcm, prop)  # 返回 shape: (len(distances), len(angles))
            feats.extend(tmp.flatten())
        feats = np.array(feats, dtype=np.float32)  # shape=(dim_glcm,)
        # print(f"[extract_glcm] GLCM 特征维度: {feats.shape}")  # (dim_glcm,)
        return feats

    def extract_bow(self, pil_img):
        if self.kmeans_model is None:
            raise RuntimeError("请先调用 build_sift_vocab() 构建视觉词典。")

        gray_arr = self._pil_to_gray_array(pil_img, levels=self.glcm_levels)  # shape=(H, W)
        gray_float = gray_arr.astype(np.float32) / 255.0

        try:
            # 提取 SIFT
            self.sift.detect_and_extract(gray_float)
        except RuntimeError:
            # 如果提取失败，返回全零向量
            hist_zero = np.zeros(self.vocab_size, dtype=np.float32)
            print(f"[extract_bow] SIFT 提取失败，返回零向量，维度: {hist_zero.shape}")
            return hist_zero

        des = self.sift.descriptors  # shape=(n_keypoints, 128)
        if des is None or des.size == 0:
            # 如果没有描述符，返回零向量
            hist_zero = np.zeros(self.vocab_size, dtype=np.float32)
            print(f"[extract_bow] 未检测到描述符，返回零向量，维度: {hist_zero.shape}")
            return hist_zero

        # 使用 KMeans 对每个 descriptor 进行聚类，返回单词索引列表
        words = self.kmeans_model.predict(des)  # shape=(n_keypoints,)
        # 计算词频直方图
        hist, _ = np.histogram(words, bins=np.arange(self.vocab_size + 1))
        hist = hist.astype(np.float32)  # shape=(vocab_size,)
        # L2 归一化
        norm = np.linalg.norm(hist)
        if norm > 0:
            hist /= norm
        # print(f"[extract_bow] BOW 特征维度: {hist.shape}")  # (vocab_size,)
        return hist

    def extract_lbp(self, pil_img):
        gray = self._pil_to_gray_array(pil_img, levels=self.glcm_levels)  # shape=(H, W)
        # 计算 LBP map，返回 shape=(H, W)，元素值在 [0, lbp_hist_size)
        lbp_map = local_binary_pattern(
            gray,
            P=self.lbp_p,
            R=self.lbp_r,
            method=self.lbp_method
        )
        # 计算 LBP 直方图
        hist, _ = np.histogram(
            lbp_map.ravel(),
            bins=np.arange(self.lbp_hist_size + 1),
            range=(0, self.lbp_hist_size)
        )
        hist = hist.astype(np.float32)  # shape=(lbp_hist_size,)
        # L2 归一化
        norm = np.linalg.norm(hist)
        if norm > 0:
            hist /= norm
        # print(f"[extract_lbp] LBP 特征维度: {hist.shape}")  # (lbp_hist_size,)
        return hist

    def extract_color_hist(self, pil_img):
        rgb_arr = self._pil_to_rgb_array(pil_img)  # shape=(H, W, 3)

        rgb_norm = rgb_arr.astype(np.float32) / 255.0  # 归一化到 [0,1]
        hsv = mcolors.rgb_to_hsv(rgb_norm)  # shape=(H, W, 3)，值在 [0,1]

        # 将 HSV 三个通道映射回 [0,255] 的整数
        h_chan = (hsv[:, :, 0] * 255).astype(np.uint8)  # shape=(H, W)
        s_chan = (hsv[:, :, 1] * 255).astype(np.uint8)
        v_chan = (hsv[:, :, 2] * 255).astype(np.uint8)

        feats = []
        # 对 H、S、V 三个通道分别计算直方图
        for chan, bins in zip([h_chan, s_chan, v_chan], self.color_hist_bins):
            hist, _ = np.histogram(chan, bins=bins, range=(0, 256))  # shape=(bins,)
            hist = hist.astype(np.float32)
            norm = np.linalg.norm(hist)
            if norm > 0:
                hist /= norm
            feats.append(hist)
        feats_concat = np.concatenate(feats)  # shape=(sum(color_hist_bins),)
        # print(f"[extract_color_hist] 颜色直方图特征维度: {feats_concat.shape}")  # (dim_color,)
        return feats_concat

    def extract_cnn(self, pil_img):
        if not self.use_cnn:
            raise RuntimeError("当前未启用 CNN 特征提取。")
        # 预处理：Resize、ToTensor、Normalize，返回 shape=(3,224,224)
        tensor = self.cnn_transform(pil_img).unsqueeze(0).to(self.device)  # shape=(1,3,224,224)
        # print(f"[extract_cnn] 输入给 ResNet50 的张量形状: {tensor.shape}")  # (1,3,224,224)
        with torch.no_grad():
            feats = self.cnn_model(tensor)  # 输出 shape=(1,2048,1,1)
        feats_flat = feats.view(-1).cpu().numpy().astype(np.float32)  # 转为 shape=(2048,)
        # print(f"[extract_cnn] ResNet50 提取后特征维度: {feats_flat.shape}")  # (2048,)
        return feats_flat

    def extract_all(self, paths):
        feats_list = []

        for path in tqdm(paths, desc="Extracting features"):
            pil_img = Image.open(path)

            f_glcm = self.extract_glcm(pil_img)  # (dim_glcm,)
            f_bow = self.extract_bow(pil_img)  # (dim_bow,)
            f_lbp = self.extract_lbp(pil_img)  # (dim_lbp,)
            f_color = self.extract_color_hist(pil_img)  # (dim_color,)

            if self.use_cnn:
                f_cnn = self.extract_cnn(pil_img)  # (dim_cnn,)
                # 将所有特征拼接：dim = dim_glcm + dim_bow + dim_lbp + dim_color + dim_cnn
                feat = np.concatenate([f_glcm, f_bow, f_lbp, f_color, f_cnn])
                # print(f"[extract_all] 图像 {path.name} 综合特征维度: {feat.shape}")  # (total_dim,)
            else:
                # 不使用 CNN 时，dim = dim_glcm + dim_bow + dim_lbp + dim_color
                feat = np.concatenate([f_glcm, f_bow, f_lbp, f_color])
                # print(f"[extract_all] 图像 {path.name} 综合特征维度: {feat.shape}")  # (total_dim,)

            feats_list.append(feat)

        # 将 list 转为 ndarray，形状 (n_samples, total_dim)
        feats_matrix = np.vstack(feats_list)
        # print(f"[extract_all] 最终特征矩阵维度: {feats_matrix.shape}")  # (n_samples, total_dim)
        return feats_matrix