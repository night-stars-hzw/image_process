from pathlib import Path
import numpy as np
import torch
from sklearn.preprocessing import StandardScaler
from sklearn.decomposition import PCA
from sklearn.svm import SVC
from sklearn.ensemble import VotingClassifier, RandomForestClassifier
from sklearn.neighbors import KNeighborsClassifier
from sklearn.naive_bayes import GaussianNB
from sklearn.metrics import confusion_matrix, precision_score, recall_score, f1_score
import matplotlib.pyplot as plt
from pylab import mpl
from dataloader import Dataloader
from feature_extractor import FeatureExtractor
def main(vocab_size, use_cnn, pca_components):
    root_dir = Path("..") / "dataset"
    num_classes = 20
    image_ext = ".jpg"
    # GLCM 参数
    default_glcm_distances = [1]
    default_glcm_angles = [0, np.pi / 4, np.pi / 2, 3 * np.pi / 4]
    glcm_levels = 256  # 灰度量化级别

    # LBP 参数
    lbp_p = 8
    lbp_r = 1
    lbp_method = "uniform"
    lbp_hist_size = 59

    # 颜色直方图参数
    color_hist_bins = (16, 16, 16)
    device = torch.device("cpu")
    # 数据加载，读取图像路径及标签
    data_loader = Dataloader(root_dir, num_classes=num_classes, ext=image_ext)
    train_paths, train_labels, test_paths, test_labels = data_loader.load_paths_and_labels()
    print(f"[main] 训练集数量: {len(train_paths)}, 测试集数量: {len(test_paths)}")

    # 初始化特征提取器, 包括 ResNet50, 并基于训练集构建 SIFT 视觉词典
    extractor = FeatureExtractor(vocab_size=vocab_size, glcm_distances=default_glcm_distances,
                                 glcm_angles=default_glcm_angles, glcm_levels=glcm_levels, lbp_p=lbp_p, lbp_r=lbp_r,
                                 lbp_method=lbp_method, lbp_hist_size=lbp_hist_size, color_hist_bins=color_hist_bins,
                                 use_cnn=use_cnn, device=device)
    extractor.build_sift_vocab(train_paths)

    # 提取训练集和测试集特征
    print("[main] 正在为训练集提取特征 …")
    x_train = extractor.extract_all(train_paths)
    print("[main] 正在为测试集提取特征 …")
    x_test = extractor.extract_all(test_paths)
    y_train = np.array(train_labels, dtype=np.int32)
    y_test = np.array(test_labels, dtype=np.int32)
    print(f"[main] x_train 形状: {x_train.shape}")
    print(f"[main] x_test 形状: {x_test.shape}")

    # 特征标准化,均值为0,方差为1
    scaler = StandardScaler()
    x_train_scaled = scaler.fit_transform(x_train)
    x_test_scaled = scaler.transform(x_test)

    # PCA降维
    if pca_components is not None:
        print(f"[PCA] 将特征从 {x_train_scaled.shape[1]} 维降到 {pca_components} 维")
        pca = PCA(n_components=pca_components, random_state=42)
        x_train_final = pca.fit_transform(x_train_scaled)  # shape=(n_train, pca_components)
        x_test_final = pca.transform(x_test_scaled)  # shape=(n_test, pca_components)
        print(f"[PCA] 完成: x_train_final 形状 = {x_train_final.shape}")
        print(f"[PCA] 完成: x_test_final 形状 = {x_test_final.shape}")
    else:
        x_train_final = x_train_scaled
        x_test_final = x_test_scaled

    # 定义多个分类器:SVM、KNN、RandomForest、Naive Bayes
    classifiers = {
        "SVM": SVC(kernel="rbf", C=1.0, gamma="scale", probability=False, random_state=42),
        "KNN": KNeighborsClassifier(n_neighbors=5),
        "RandomForest": RandomForestClassifier(n_estimators=100, random_state=42),
        "NaiveBayes": GaussianNB()
    }
    metrics_dict = {}

    # 训练并评估各单模型
    for name, clf in classifiers.items():
        print(f"\n[{name}] 开始训练 …")
        clf.fit(x_train_final, y_train)
        print(f"[{name}] 训练完成，开始预测测试集 …")
        preds = clf.predict(x_test_final)  # preds 形状=(n_test,)

        prec = precision_score(y_test, preds, average="macro")
        rec = recall_score(y_test, preds, average="macro")
        f1 = f1_score(y_test, preds, average="macro")
        metrics_dict[name] = {
            "Precision": prec,
            "Recall": rec,
            "F1": f1,
            "Preds": preds
        }
        print(f"[{name}] Macro-Precision: {prec:.4f}  Macro-Recall: {rec:.4f}  Macro-F1: {f1:.4f}")

    # # 构建 VotingClassifier，并评估
    # voting_estimators = [
    #     ("svm", SVC(kernel="rbf", C=1.0, gamma="scale", probability=True, random_state=42)),
    #     ("knn", KNeighborsClassifier(n_neighbors=5)),
    #     ("rf", RandomForestClassifier(n_estimators=100, random_state=42)),
    #     ("nb", GaussianNB())
    # ]
    # voting_clf = VotingClassifier(
    #     estimators=voting_estimators,
    #     voting="soft"
    # )
    # print("\n[Voting] 开始训练 …")
    # voting_clf.fit(x_train_final, y_train)
    # print("[Voting] 训练完成，开始预测测试集 …")
    # preds_vote = voting_clf.predict(x_test_final)  # shape=(n_test,)
    #
    # prec_v = precision_score(y_test, preds_vote, average="macro")
    # rec_v = recall_score(y_test, preds_vote, average="macro")
    # f1_v = f1_score(y_test, preds_vote, average="macro")
    # metrics_dict["Voting"] = {
    #     "Precision": prec_v,
    #     "Recall": rec_v,
    #     "F1": f1_v,
    #     "Preds": preds_vote
    # }
    # print(f"[Voting] Macro-Precision: {prec_v:.4f}  Macro-Recall: {rec_v:.4f}  Macro-F1: {f1_v:.4f}")

    # 选出 F1 分数最高的最佳模型
    best_model_name = max(metrics_dict, key=lambda name: metrics_dict[name]["F1"])
    best_metrics = metrics_dict[best_model_name]
    best_preds = best_metrics["Preds"]

    print("\n===== 最优模型与对应宏平均指标 =====")
    print(f"模型名称：{best_model_name}")
    print(f"Macro-Precision: {best_metrics['Precision']:.4f}")
    print(f"Macro-Recall   : {best_metrics['Recall']:.4f}")
    print(f"Macro-F1       : {best_metrics['F1']:.4f}")

    # 将最佳模型的预测结果保存到文件，保留原始图片文件名
    out_txt = f"{best_model_name.lower()}_best_preds.txt"
    with open(out_txt, "w") as f:
        # 如果需要表头，可取消下面一行注释：
        f.write("filename true_label pred_label\n")
        for path, true_label, pred_label in zip(test_paths, test_labels, best_preds):
            f.write(f"{path.name} {true_label} {pred_label}\n")
    print(f"[Output] 最优模型 ({best_model_name}) 的预测结果已保存到：{out_txt}")

    # 计算混淆矩阵
    cm_counts = confusion_matrix(y_test, best_preds, labels=list(range(num_classes)))
    cm_prob = cm_counts.astype(np.float32) / cm_counts.sum(axis=1, keepdims=True)

    # 计算每个类别的准确率A_i及平均准确率A
    class_accuracies = np.diag(cm_prob)  # 取对角线，shape=(num_classes,)
    average_accuracy = class_accuracies.mean()
    print("\n===== 每个类别的分类准确率 ai =====")
    for i, acc in enumerate(class_accuracies):
        print(f"类别 {i:2d} 准确率: {acc:.4f}")
    print(f"\n===== 平均分类准确率 a =====\nA = {average_accuracy:.4f}")
    mpl.rcParams['font.sans-serif'] = ['SimHei']
    plt.figure(figsize=(10, 8))
    im = plt.imshow(cm_prob, interpolation="nearest", cmap='Blues', aspect="auto")
    plt.title(f"{best_model_name} 归一化混淆矩阵\n平均准确率 a = {average_accuracy:.4f}", fontsize=14)
    plt.colorbar(im, fraction=0.046, pad=0.04)
    tick_marks = np.arange(num_classes)
    plt.xticks(tick_marks, [str(i) for i in range(num_classes)], rotation=90, fontsize=8)
    plt.yticks(tick_marks, [str(i) for i in range(num_classes)], fontsize=8)
    plt.xlabel("预测类别", fontsize=12)
    plt.ylabel("真实类别", fontsize=12)
    thresh = cm_prob.max() / 2.0
    for i in range(num_classes):
        for j in range(num_classes):
            plt.text(j, i, f"{cm_prob[i, j]:.2f}", horizontalalignment="center", verticalalignment="center",
                     color="white" if cm_prob[i, j] > thresh else "black", fontsize=6)
    plt.tight_layout()
    plt.show()


if __name__ == "__main__":
    vocab_size = 200
    use_cnn = True
    pca_components = 70
    main(vocab_size, use_cnn, pca_components)
